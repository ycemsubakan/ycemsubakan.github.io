function drand =  randdirichlet(a,n)
% function drand =  randdirichlet(a,n)
% a - vector of parameters 1 x m.
% n - how many to simulate
% drand - m x n  matrix, each column is a realization
%----------------------------------------------------
a=a(:);
m=size(a,1);
a1=zeros(m,n);
for i = 1:m
    a1(i,:) = gamrnd(a(i,1),1,1,n);
end

for i=1:m
    drand(i, 1:n )= a1(i, 1:n ) ./ sum(a1);
end

if isnan(drand)
    keyboard;
end