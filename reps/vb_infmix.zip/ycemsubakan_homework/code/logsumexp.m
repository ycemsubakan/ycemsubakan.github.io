function lse = logsumexp(log_p,dim)
    
if nargin == 1
    dim = 1;
end

lse = log(sum(exp( bsxfun(@minus,log_p, max(log_p,[],dim))),dim ) ) + max(log_p,[],dim);


% for s=1:size(y,1);
%     for j = 1: K
%         
%         O_num(:,j,s) = log(resp(s)) + logsumexp(bsxfun(@plus,log_gamma{s}(j,:),log(y{s}) )')';
%         O_denum(:,j,s) = log(resp(s))  + logsumexp( log_gamma{s}(j,:)' )';
%     end
% end
% hm.O = exp(logsumexp(O_num,3) - logsumexp(O_denum,3));