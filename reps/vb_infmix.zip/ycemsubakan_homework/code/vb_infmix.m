clear,
close all,
clc,

%set seed for reproducibility
rng(3)

%addpath('../../utilities_v2/utils/')

%set number of data items N, number of true clusters K, number of
%dimensions L
N = 500;
K = 3;
L = 2;

%set true parameters
sig_0 = 10;
mu_0 = 0;
sig = 1;

%generate data
W = mu_0 + sig_0*randn(L,K);
z = randi([1 K],1,N);
x = W(:,z) + sig*randn(2,N);

%plot the data
figure(1)
plot(x(1,:),x(2,:),'o')

%set novely parameter (stick breaking rate)
al = 400;

%number clusters in the truncated variational distribution
Kp = 20;

%%%% start variational Bayes %%%%  

%initialize zhat
phat = zeros(Kp-1,N);
for i = 1:N
    phat(z(i),i) = 1;
end
phat = randdirichlet(repmat(0.6,[1 Kp-1]),N);
phat(end+1,:) = 0;

%allocate space for other parameters
mu_k = zeros(L,Kp);
sigma2_k = zeros(Kp,1);
al_hat = zeros(Kp,1);
b_hat = zeros(Kp,1);

%start iterating
for e = 1:140;
    %%%%%%%%%plot the clustering at each iteration
    [~,zhat] = max(phat,[],1); % find hard cluster assignments for visualization
    labs = unique(zhat);
    
    for l = 1:length(labs)
        zhat(zhat == labs(l)) = l;
    end
    
    %plot
    colors = 'rgykmbrgykmbrgykmb';
    figure(2)
    plot(x(1,:),x(2,:),'o')
    for k = 1:min([length(colors),length(labs)])
        
        hold on;plot( x(1,zhat == k),x(2,zhat == k),[colors(k),'o'] );hold off;
        hold on;plot(mu_k(1,labs(k)),mu_k(2,labs(k)),[colors((k)),'x'],'Markersize',14,'Linewidth',4);hold off
    end
    
    drawnow
    disp(e)
    %%%%%%%%%
    
    %update Nk
    Nk = sum(phat,2);
    disp(Nk)
    
    for k = 1 : Kp - 1
        
        %update \bar{\mu}_k and \bar{\sigma}^2_k
        ip = sum(bsxfun(@times,phat(k,:),x),2);
        mu_k(:,k) = ((sig^2)*mu_0 + (sig_0^2)*ip ) / (Nk(k)*(sig_0^2) + sig^2);
        sigma2_k(k) = ((sig^2) * sig_0^2) / (Nk(k)*(sig_0^2) + sig^2 );
        
        %update \bar{\alpha}_k and \bar{\beta}_k
        al_hat(k) = al + sum(phat(k,:));
        b_hat(k) = 1 + sum(sum(phat(k+1:end,:)));                
        
    end
    
    %update \bar{p}_k
    logphat = log(ones(Kp-1,N)/(Kp-1));
    for n = 1: N
        for k = 1 : Kp - 1
            
            logphat(k,n) = -(0.5/sig^2)*(mu_k(:,k)'*mu_k(:,k) + L*sigma2_k(k)) + (1/sig^2)*mu_k(:,k)'*x(:,n) + (psi(al_hat(k)) - psi(al_hat(k) + b_hat(k)) )  + sum(psi(b_hat(1:k-1)) - psi(al_hat(1:k-1) + b_hat(1:k-1))) ;
            
        end
        
        phat(:,n) = [exp( logphat(:,n) - logsumexp(logphat(:,n)) ); 0];
    end
    
    
end
